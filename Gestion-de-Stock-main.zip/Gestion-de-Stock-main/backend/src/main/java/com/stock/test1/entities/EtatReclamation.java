package com.stock.test1.entities;

public enum EtatReclamation {
    EN_COURS,
    ACCEPTEE,
    REFUSEE
}
